var parent = require('../es/escape');

module.exports = parent;
