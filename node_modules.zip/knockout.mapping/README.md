Object mapping plugin for [Knockout](http://knockoutjs.com/) - Find the documentation [here](http://knockoutjs.com/documentation/plugins-mapping.html).

Introduction
---

Due to lack of time this project was no longer actively maintained by the [original author](https://github.com/SteveSanderson/knockout.mapping/fork). I've forked it mostly because I needed to add a `package.json` to install it as a dependency via NPM.
