var convert = require('./convert'),
    func = convert('deburr', require('../deburr'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
