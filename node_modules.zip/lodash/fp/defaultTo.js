var convert = require('./convert'),
    func = convert('defaultTo', require('../defaultTo'));

func.placeholder = require('./placeholder');
module.exports = func;
