---
title: "JSZip API"
layout: default
section: api
---

An instance of JSZip represents a set of files. You can add them, remove them,
modify them. You can also import an existing zip file or generate one.
